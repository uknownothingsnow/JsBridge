package com.github.lzyzsd.jsbridge;

/**
 * Created on 2019/7/10.
 * Author: bigwang
 * Description:
 */
class JSRequest {

    public String callbackId;

    public String data;

    public String handlerName;
}
