package com.github.lzyzsd.jsbridge;

public interface OnBridgeCallback {
	
	void onCallBack(String data);

}
